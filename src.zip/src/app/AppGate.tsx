import { useEffect, useRef, useState, ReactNode } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { getSupabase } from '../lib/supabase'

/**
 * AppGate: Single source of truth for post-onboarding redirects
 * - Handles routing after login + email verification
 * - Redirects to role selection if no role
 * - Redirects to onboarding if not completed
 * - Redirects to dashboard if onboarding completed
 * - Prevents navigation loops by checking current location
 */
export default function AppGate({ children }: { children: ReactNode }) {
  const { session, loading: authLoading } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const supabase = getSupabase()

  const [isProcessing, setIsProcessing] = useState(false)
  const hasRedirected = useRef(false)

  useEffect(() => {
    if (authLoading) return
    if (hasRedirected.current) return
  
    if (!session) {
      hasRedirected.current = true
      navigate('/login', { replace: true })
      return
    }
  
    if (!session.user.email_confirmed_at) {
      hasRedirected.current = true
      supabase.auth.signOut().finally(() => {
        navigate('/login', { replace: true })
      })
      return
    }
  
    runGate()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, session])  

  async function runGate() {
    if (hasRedirected.current) return
    if (isProcessing) return
    
    setIsProcessing(true)
    hasRedirected.current = true
  
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('id, role, onboarding_completed')
      .eq('id', session!.user.id)
      .maybeSingle()
  
    console.log('RUN GATE PROFILE FROM DB:', profile)
  
    if (error || !profile) {
      navigate('/role', { replace: true })
      return
    }
  
    if (!profile.role) {
      navigate('/role', { replace: true })
      return
    }
  
    if (!profile.onboarding_completed) {
      navigate(`/onboarding/${profile.role}`, { replace: true })
      return
    }
  
    // Onboarding completed - redirect to dashboard
    // Check if we're already on a dashboard route to prevent loops
    const targetPath = profile.role === 'creator' ? '/dashboard/creator' : '/dashboard/brand'
    if (location.pathname !== targetPath) {
      navigate(targetPath, { replace: true })
    }
  }  

  // Show loading only while processing
  if (authLoading || isProcessing) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#6B7280]">Đang tải...</div>
      </div>
    )
  }

  // Render children when gate checks pass
  return <>{children}</>
}
