import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { useProfile } from '../hooks/useProfile'
import LandingPage from '../pages/public/LandingPage'
import LoginPage from '../pages/public/LoginPage'
import SignupPage from '../pages/public/SignupPage'
import VerifyEmailPage from '../pages/public/VerifyEmailPage'
import AppGate from './AppGate'
import RolePage from '../pages/onboarding/RolePage'
import OnboardingPage from '../pages/onboarding/OnboardingPage'
import TermsPage from '../pages/public/TermsPage'
import PrivacyPage from '../pages/public/PrivacyPage'
import { CreatorRoutes } from './creatorRoutes'
import { BrandRoutes } from './brandRoutes'
import DashboardRoutes from './dashboardRoutes'

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { session, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#6B7280]">Đang tải...</div>
      </div>
    )
  }

  if (!session) {
    return <Navigate to="/login" replace />
  }

  return <>{children}</>
}

/**
 * PublicRoute: Redirects authenticated users away from public pages
 * - If user is authenticated and onboarded, redirect to dashboard
 * - If user is authenticated but not onboarded, redirect to /app (AppGate handles onboarding)
 * - Otherwise, show public page
 */
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { session, loading } = useAuth()
  const { profile, loading: profileLoading } = useProfile(
    session?.user?.id,
    !!(session && session.access_token && session.user.email_confirmed_at)
  )

  if (loading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#6B7280]">Đang tải...</div>
      </div>
    )
  }

  if (session) {
    // If user is onboarded, redirect directly to dashboard (bypass /app)
    if (profile?.onboarding_completed && profile?.role) {
      const dashboardPath = profile.role === 'creator' ? '/dashboard/creator' : '/dashboard/brand'
      return <Navigate to={dashboardPath} replace />
    }

    return null
  }

  return <>{children}</>
}

/**
 * RoleBasedRoute: Protects routes that require a specific role
 * - Redirects to correct dashboard if role mismatch (bypass /app)
 * - Redirects to /app only if no role is set (AppGate handles role selection)
 */
function RoleBasedRoute({ children, requiredRole }: { children: React.ReactNode; requiredRole: 'creator' | 'brand' }) {
  const { session, loading: authLoading } = useAuth()
  const { profile, loading: profileLoading } = useProfile(
    session?.user?.id,
    !!(session && session.access_token && session.user.email_confirmed_at)
  )

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#6B7280]">Đang tải...</div>
      </div>
    )
  }

  if (!session || !profile) {
    return <Navigate to="/login" replace />
  }

  if (profile.role !== requiredRole) {
    // Redirect to correct dashboard based on actual role (bypass /app)
    if (profile.role === 'creator') {
      return <Navigate to="/dashboard/creator" replace />
    } else if (profile.role === 'brand') {
      return <Navigate to="/dashboard/brand" replace />
    }
    // No role set - let AppGate handle it
    return <Navigate to="/login" replace />
  }

  return <>{children}</>
}

/**
 * CatchAllRoute: Handles 404s and unknown routes
 * - If authenticated and onboarded, redirect to dashboard (bypass /app)
 * - If authenticated but not onboarded, redirect to /app (AppGate handles onboarding)
 * - If not authenticated, redirect to login
 */
function CatchAllRoute() {
  const { session, loading } = useAuth()
  const { profile, loading: profileLoading } = useProfile(
    session?.user?.id,
    !!(session && session.access_token && session.user.email_confirmed_at)
  )

  if (loading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-[#6B7280]">Đang tải...</div>
      </div>
    )
  }

  if (session) {
    // If user is onboarded, redirect directly to dashboard (bypass /app)
    if (profile?.onboarding_completed && profile?.role) {
      const dashboardPath = profile.role === 'creator' ? '/dashboard/creator' : '/dashboard/brand'
      return <Navigate to={dashboardPath} replace />
    }
    // Otherwise, let AppGate handle routing
    return <Navigate to="/login" replace />
  }

  // No session - redirect to login
  return <Navigate to="/login" replace />
}

export function Router() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      
      <Route
        path="/login"
        element={
          <PublicRoute>
            <LoginPage />
          </PublicRoute>
        }
      />
      
      <Route
        path="/signup"
        element={
          <PublicRoute>
            <SignupPage />
          </PublicRoute>
        }
      />
      
      <Route path="/verify-email" element={<VerifyEmailPage />} />

      <Route path="/terms" element={<TermsPage />} />
      <Route path="/privacy" element={<PrivacyPage />} />

      <Route
        path="/role"
        element={
          <ProtectedRoute>
            <RolePage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/onboarding/:role?"
        element={
          <ProtectedRoute>
            <OnboardingPage />
          </ProtectedRoute>
        }
      />

      <Route
        path="/dashboard/:role/*"
        element={
          <ProtectedRoute>
            <DashboardRoutes />
          </ProtectedRoute>
        }
      />

      <Route
        path="/creator/*"
        element={
          <RoleBasedRoute requiredRole="creator">
            <CreatorRoutes />
          </RoleBasedRoute>
        }
      />

      <Route
        path="/brand/*"
        element={
          <RoleBasedRoute requiredRole="brand">
            <BrandRoutes />
          </RoleBasedRoute>
        }
      />

      <Route path="*" element={<CatchAllRoute />} />
    </Routes>
  )
}

