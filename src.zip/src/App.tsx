import { BrowserRouter, useLocation } from 'react-router-dom'
import { Router } from './app/router'
import ScrollToTop from './components/shared/ScrollToTop'
import Header from './components/layout/Header'
import Footer from './components/layout/Footer'
import AppGate from './app/AppGate'

function AppContent() {
  const location = useLocation()
  
  const isDashboardMode = location.pathname.startsWith('/creator') || location.pathname.startsWith('/brand')
  
  return (
    <div className="min-h-screen flex flex-col">
      {!isDashboardMode && <Header />}
      <main className="flex-1">
        <Router />
      </main>
      {!isDashboardMode && <Footer />}
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <AppGate>
    <AppContent />
      </AppGate>
    </BrowserRouter>
  )
}

export default App

